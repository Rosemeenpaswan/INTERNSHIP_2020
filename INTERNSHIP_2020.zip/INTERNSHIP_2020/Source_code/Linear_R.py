# -*- coding: utf-8 -*-
"""
Created on Sat Jul 25 20:20:40 2020

@author: Rosemeen paswan
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn import linear_model



data=pd.read_csv(r"C:\Users\Rosemeen paswan\Desktop\INTERN_2020\DATA.csv")
print("Data heads:")
print(data.head())
print("Null values in the dataset before preprocessing:")
print(data.isnull().sum())
print("Filling null values with mean of that particular column")
data=data.fillna(np.mean(data))
print("Mean of data:")
print(np.mean(data))
print("Null values in the dataset after preprocessing:")
print(data.isnull().sum())
print("\n\nShape: ",data.shape)

#print("Info:")
#print(data.info())

print("Histograms showing the data of rainfall measures")
data['rainfall_1'].hist(bins=20,label = 'rainfall_1')
data['rainfall_2'].hist(bins=20 ,label = 'rainfall_2')
#data['actual'].hist(bins=20, label = 'actual')
plt.legend()


data = pd.get_dummies(data)
data.iloc[:,5:].head(5)


print("___Multiple Linear regression model between annual rainfall and the periodic rainfall___")
y=data['actual']
x=data[['year','month','week_Fri','week_Mon','week_Sat','week_Sun','week_Thurs','week_Tues','week_Wed','day','rainfall_1','rainfall_2','friend','mean']]

x_list = list(x.columns)
x = np.array(x)

train_x,test_x,train_y,test_y=train_test_split(x,y,test_size=0.25,shuffle=False)
'''train_x=train_x[:,np.newaxis]
test_x=test_x[:,np.newaxis]'''
print("Train x shape",train_x.shape,"; Test_x",test_x.shape)
print("Train y shape",train_y.shape,"; Test_y",test_y.shape)


#linear Regression model
lm=linear_model.LinearRegression()
lm.fit(train_x,train_y)
pred=lm.predict(test_x)
errors = abs(pred - test_y)
mape = 100 * (errors / test_y)
print('Mean Absolute Error:', round(np.mean(errors), 2), 'degrees.')
accuracy = (100 - np.mean(mape))
print('Accuracy using LINEAR REGRESSION model:', round(accuracy, 2), '%.')




