# -*- coding: utf-8 -*-
"""
Created on Thu Aug  6 20:41:03 2020

@author: Rosemeen paswan
"""


import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import utils
from sklearn import preprocessing
from sklearn.svm import SVC

data=pd.read_csv(r"C:\Users\Rosemeen paswan\Desktop\INTERN_2020\DATA.csv")
print("Data heads:")
print(data.head())
print("Null values in the dataset before preprocessing:")
print(data.isnull().sum())
print("Filling null values with mean of that particular column")
data=data.fillna(np.mean(data))
print("Mean of data:")
print(np.mean(data))
print("Null values in the dataset after preprocessing:")
print(data.isnull().sum())
#data = data.replace('NA', data) 
#data.to_csv('TEMPS_.csv') 
print("\n\nShape: ",data.shape)

print("Info:")
print(data.info())
data.describe()



data = pd.get_dummies(data)

y=np.array(data['actual'])
x=data[['year','month','week_Fri','week_Mon','week_Sat','week_Sun','week_Thurs','week_Tues','week_Wed','day','rainfall_1','rainfall_2','friend','mean']]
x_list = list(x.columns)
x = np.array(x)

train_x,test_x,train_y,test_y=train_test_split(x,y,test_size=0.3,shuffle=False)


lab_enc = preprocessing.LabelEncoder()
training_scores_encoded = lab_enc.fit_transform(train_y)
print(training_scores_encoded)
print(utils.multiclass.type_of_target(train_y))
print(utils.multiclass.type_of_target(train_y.astype('int')))
print(utils.multiclass.type_of_target(training_scores_encoded))

classifier = SVC(kernel = 'linear',random_state = 0)
classifier.fit(train_x, training_scores_encoded)
pred_y=classifier.predict(test_x)
errors = abs(pred_y - test_y)
mape = 100 * (errors / test_y)
accuracy = -(100 - np.mean(mape))
print('Accuracy using SVM :', round(accuracy, 2), '%.')
