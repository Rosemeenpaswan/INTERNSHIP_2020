# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 19:11:46 2020

@author: Rosemeen paswan
"""

import pandas as pd
import numpy as np
#from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import matplotlib.pyplot as plt
import datetime


#DATA PREPROCESSING
data=pd.read_csv(r"C:\Users\Rosemeen paswan\Desktop\INTERN_2020\DATA.csv")
print("Data heads:")
print(data.head())
print("Null values in the dataset before preprocessing:")
print(data.isnull().sum())
print("Filling null values with mean of that particular column")
data=data.fillna(np.mean(data))
print("Mean of data:")
print(np.mean(data))
print("Null values in the dataset after preprocessing:")
print(data.isnull().sum())
#data = data.replace('NA', data) 
#data.to_csv('TEMPS_.csv') 
print("\n\nShape: ",data.shape)

print("Info:")
print(data.info())
data.describe()


#print("Co-Variance =",data.cov())
#print("Co-Relation =",data.corr())

#plt.subplots(figsize=(12,5))

plt.plot(data.rainfall_2,'b', label='rainfall_2')
plt.plot(data.rainfall_1,'-.r',label='rainfall_1')
#plt.plot(data.actual,'r',label='actual')
plt.ylabel("rainfall (mm)")
plt.title("actual rainfall measure")
plt.legend()

#one_hot vector
data = pd.get_dummies(data)
data.iloc[:,5:].head(5)


labels = np.array(data['actual'])
print(labels)
features= data.drop('actual', axis = 1)
print(features)
# Saving feature names for later use

feature_list = list(features.columns)
features = np.array(features)

# Split the data into training and testing sets
train_features, test_features, train_labels, test_labels = train_test_split(features, labels, test_size = 0.25, random_state = 42)
print('Training Features Shape:', train_features.shape)
print('Training Labels Shape:', train_labels.shape)
print('Testing Features Shape:', test_features.shape)
print('Testing Labels Shape:', test_labels.shape)


# Baseline errors, and display average baseline error
baseline_preds = test_features[:, feature_list.index('mean')]
baseline_errors = abs(baseline_preds - test_labels)
print('Average baseline error: ', round(np.mean(baseline_errors), 2))

rf = RandomForestRegressor(n_estimators = 1000, random_state = 42)
rf.fit(train_features, train_labels)

predictions = rf.predict(test_features)
errors = abs(predictions - test_labels)

print('Mean Absolute Error:', round(np.mean(errors), 2), 'degrees.')

mape = 100 * (errors / test_labels)
accuracy = 100 - np.mean(mape)
print('Accuracy using RANDOM FOREST model:', round(accuracy, 2), '%.')




#tree_1= rf.estimators_[5]
#fn=features
#cn=labels
#fig, axes = plt.subplots(nrows = 1,ncols = 1,figsize = (4,4), dpi=300)
#tree.plot_tree(rf.estimators_[0],
#               feature_names = fn, 
#               class_names=cn,
#               filled = True);
#               
#plt.show()

               
months = features[:, feature_list.index('month')]
days = features[:, feature_list.index('day')]
years = features[:, feature_list.index('year')]
# List and then convert to datetime object
dates = [str(int(year)) + '-' + str(int(month)) + '-' + str(int(day)) for year, month, day in zip(years, months, days)]
dates = [datetime.datetime.strptime(date, '%Y-%m-%d') for date in dates]
# Dataframe with true values and dates
true_data = pd.DataFrame(data = {'date': dates, 'actual': labels})

# Dates of predictions
months = test_features[:, feature_list.index('month')]
days = test_features[:, feature_list.index('day')]
years = test_features[:, feature_list.index('year')]
# Column of dates
test_dates = [str(int(year)) + '-' + str(int(month)) + '-' + str(int(day)) for year, month, day in zip(years, months, days)]

# Convert to datetime objects
test_dates = [datetime.datetime.strptime(date, '%Y-%m-%d') for date in test_dates]
# Dataframe with predictions and dates
predictions_data = pd.DataFrame(data = {'date': test_dates, 'prediction': predictions})
# Plot the actual values
plt.plot(true_data['date'], true_data['actual'], 'b-', label = 'actual')
# Plot the predicted values3
plt.plot(predictions_data['date'], predictions_data['prediction'], 'ro', label = 'prediction')
plt.xticks(rotation = '60'); 
plt.legend()
# Graph labels
plt.xlabel('Year-Month'); plt.ylabel('Maximum Rainfall (mm)'); plt.title('Actual and Predicted Values');



# Make the data accessible for plotting
#true_data['rainfall_1'] = features[:, feature_list.index('rainfall_1')]
#true_data['mean'] = features[:, feature_list.index('mean')]
#true_data['friend'] = features[:, feature_list.index('friend')]
# Plot all the data as lines
#plt.plot(true_data['date'], true_data['actual'], 'b--', label  = 'actual', alpha = 1.0)
#plt.plot(true_data['date'], true_data['rainfall_1'], 'b-', label  = 'rainfall_1', alpha = 1.0)
#plt.plot(true_data['date'], true_data['mean'], 'r', label = 'mean', alpha = 0.8)
#plt.plot(true_data['date'], true_data['friend'], 'r-', label = 'friend', alpha = 0.3)
## Formatting plot
#plt.legend(); 
#plt.xticks(rotation = '60');
#plt.grid()
## Lables and title
#plt.xlabel('Year-Month'); plt.ylabel('Maximum Rainfall (mm) '); plt.title('estimated by third person');